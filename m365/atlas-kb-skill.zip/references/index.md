# ATLAS 知識庫(去識別化版)

> ⚠ **去識別化版本**(2026-09-21 14:33 產生)。客戶識別字樣已替換為中性名稱、程式錨點改為純文字;但**系統結構、畫面代號、表名、錯誤訊息、已知缺陷位置全部保留**——這些與命名無關,公開前請逐頁審閱。去識別化 ≠ 去風險。

> **一個人維護 ATLAS 的入口。**這一頁不講內容,只負責把你送到對的那一份。全部離線可讀,雙擊 `.html` 即開,不需要起 server、不需要網路。規模:畫面 911 · 實體表 437 · 報表範本 608 · 缺陷 1,682 條 · **兩條死碼線聯集 151 支畫面一按就 NRE**。

## 0. 先讀這份

| 第一份 | 為什麼 |
|---|---|
| **ATLAS 系統介紹(業務軸)** | 接手的人讀的第一份。六條業務線從開戶讀到報表,一日作業時序、角色與四眼、模組地圖都在裡面。**軸線是業務,不是程式。** |

**讀序**:`OVERVIEW` → `CHEATSHEET`(骨幹速查,可列印)→ `architecture`(技術通則)→ 自己負責模組的那一篇 → `runbooks`(要動手時)。

| 接著 | 一句話 |
|---|---|
| 速查卡 CHEATSHEET | 一頁 A4 雙面:代號規則、六層、主明細三處同名、四眼 13 欄、PO 基底黑白名單、部署矩陣、常用指令、已知坑前十型 |
| 症狀路由表 TROUBLESHOOT | 「遇到 X → 先看哪份的哪節」;最後一節列**文件裡還沒有答案**的症狀,省得你白找 |

## 1. 我要查(三個離線查詢頁)

| 頁 | 什麼時候開 |
|---|---|
| 畫面 / 表反查 query | 手上有一個代號或表名:六層檔案路徑、主明細、**PO 基底(死畫面標紅)**、誰在 SQL 裡讀寫這張表、對應的文件章節 |
| 錯誤訊息反查 messages | 線上噴了一句中文訊息:反查是哪支程式哪一行丟的。模組篇引用的訊息有意譯的,**要原文以這頁為準** |
| 缺陷總表 defects | 要動某個模組之前:先看它已知有什麼坑。可依模組 / 畫面 / 嚴重度 / 型別篩選排序 |

## 2. 我要改

### 2.1 我要做 X,看哪本

| 我要… | 看哪本 | 從哪節開始 |
|---|---|---|
| 欄位要多一個 | add-column | `§2–§9` |
| 欄位改型別或長度 | add-column | `§0 不適用,先問` |
| 報表要多印一欄 | add-report | `§2 第一列` |
| 報表版面要調 | add-report | `§5` |
| 要一支全新的畫面 | add-screen | `全篇` |
| 要一支新的查詢畫面 | add-query-screen | `§1 差異表` |
| 要一支新的批次 | add-batch | `全篇` |
| 覆核時要多一條檢核 | change-eva-flow | `§4.1` |
| 新增時要自動帶值 / 流水號 | change-eva-flow | `§4.2` |
| 要加稽核軌跡 | change-eva-flow | `§4.3` |
| 要改 SP / Function / Trigger | change-sp-fn-trigger | `全篇` |
| SP 在資料庫有、repo 沒有 | change-sp-fn-trigger | `§2` |
| 改完了要送測試 / 正式 | deploy | `§2 對照表` |
| WindowsService 要重裝或改帳號 | deploy | `§5` |
| 新人要把環境架起來 | build-env | `§0.1 三個前提` |
| 編不過 / 改了沒效果 | build-env | `§8 症狀表` |

### 2.2 九本手冊

| 手冊 | 一句話 | 行數 |
|---|---|---|
| add-column | 最常用。在既有畫面上加一個欄位 | 591 |
| add-screen | 從零建一支 M 維護畫面 | 752 |
| add-query-screen | 從零建一支 I 查詢畫面(M 的減法版) | 452 |
| add-batch | 從零建一支 B 批次 | 652 |
| change-sp-fn-trigger | 加 / 改 PL/SQL 物件 | 499 |
| add-report | 加 / 改 Crystal 報表 | 292 |
| change-eva-flow | 改四眼流程:加檢核、加稽核、改預設值 | 272 |
| deploy | 部署:改了什麼要佈哪些 | 354 |
| build-env | 建置環境:新人第一天 | 224 |

### 2.3 部署矩陣(縮版)

一句話:**改 UI 佈客戶端,改其餘五層佈伺服端,`View.xsd` 兩端都要。**完整表在 部署手冊 §2,展開說明在 速查卡 §6。

| 改了 | 客戶端 | 伺服端 IIS | WindowsService | DB |
|---|---|---|---|---|
| `UI.<MOD>` | ✔ |  |  |  |
| `UIEntity.<MOD>`(`View.xsd`) | ✔ | ✔ | ✔ |  |
| `FormProxy` / `Control` / `PO` / `DataEntity`(`Model.xsd`) |  | ✔ |  |  |
| `TA.DataAccess`(四眼引擎) |  | ✔ |  |  |
| 共用層(`TA.MappingCode` / `TA.Utility*` / `Exceptions`) | ✔ | ✔ | ✔ |  |
| 報表範本 | ✔ 檢視 | ✔ 產出 |  |  |
| SP / Function / Trigger / View / 表結構 |  |  |  | ✔ |

⚠ 先查你改的組件在不在 **DLL 覆寫名單**裡:在名單裡的話,只重編不更新預編 DLL 落點等於沒改,而且開發機上看不出來(`runbooks/deploy.md §2.1`)。

## 3. 我要懂

### 3.1 技術總覽

| 篇 | 一句話 |
|---|---|
| 架構總覽 architecture | 技術軸的總綱:六層與命名鐵律、四眼引擎、資料存取與 SQL、typed DataSet、Remoting 邊界、掃描母體與十一個掃描器缺陷。**不要整份讀**,用左側目錄跳到你要的那一節 |

### 3.2 模組文件 29 篇

一模組一篇,講**這個模組在做什麼業務**:資料模型、每支畫面的檢核與四眼、批次與報表、改它的表會影響誰。每篇的附錄 E 是該片的踩雷清單。

| 篇 | 管什麼 | 行數 |
|---|---|---|
| bbs | BBS(受益憑證作業,推測) | 1668 |
| bms | BMS(受益人基本資料與資料變更,推測) | 1546 |
| cas | CAS（代銷通路業績管理，推測） | 1916 |
| cls | CLS(直銷潛在客戶與拜訪管理,推測) | 1323 |
| cod | COD（代碼檔與員工主檔，推測） | 1401 |
| cpm | CPM（需求處理件／抱怨記錄件／客訴件的簽核流程，推測） | 1388 |
| crm | CRM（潛在客戶與直銷指派管理，推測） | 1723 |
| dsm | DSM(直銷業務管理,推測) | 2000 |
| ec | EC(網路交易平台,推測) | 1873 |
| misc | MISC(TRP / OTA / FSK / IJP 零星模組,推測) | 1729 |
| nfdr1 | NFDR1（NFD 報表第 1 片，推測） | 1339 |
| nfdr2 | NFDR2(NFD 報表第 2 片,推測) | 1660 |
| ofd123 | OFD1-3(OFD 模組第 1–3 片,推測) | 1490 |
| ofd4 | OFD4(OFD 模組第 4 片,推測) | 1526 |
| ofd5 | OFD5(OFD 模組第 5 片,推測) | 1729 |
| ofd6 | OFD6(OFD 模組第 6 片,推測) | 1543 |
| ofd7 | OFD7(OFD 模組第 7 片,推測) | 1360 |
| ofd8 | OFD8(OFD 模組第 8 片,推測) | 1739 |
| ofd9 | OFD9(OFD 模組第 9 片,推測) | 2119 |
| ofdb | OFDB(OFD 模組批次片,推測) | 1801 |
| ofdb3 | OFDB3(OFD 批次第 3 片,推測) | 1678 |
| ofdb4 | OFDB4(OFD 批次第 4 片,推測) | 1412 |
| ofdb5 | OFDB5(OFD 批次第 5 片:OFDB / OTAB 兩專案,推測) | 1764 |
| ofdi1 | OFDI1(OFD 查詢畫面第 1 片:ATLAS.OFD.Query,推測) | 1483 |
| ofdi2 | OFDI2(查詢畫面第 2 片:OTA.Query / EC.Query,推測) | 1697 |
| ofdr1 | OFDR1(OFD 報表第 1 片:ATLAS.OFD.Report,推測) | 1653 |
| ofdr2 | OFDR2(報表第 2 片:OTA.Report / EC.Report,推測) | 1246 |
| rsp | RSP(定期定額,推測) | 2306 |
| tmk | TMK(電話行銷 Telemarketing / CallOut,推測) | 1457 |

## 4. 用 AI 問(Copilot agent)

同一份知識庫也做成了 Copilot agent:直接問代號、表名、錯誤訊息,它查完附出處回答。

| 要用在 | 怎麼做 |
|---|---|
| **M365 Copilot(Agent Builder)建置清單** | 逐步清單:要貼的名稱、描述、指示、建議提示都有複製鈕;技能包與知識檔直接下載 |
| atlas-kb-skill.zip | Agent Builder「技能」上傳用(SKILL.md + 完整知識庫) |
| atlas-kb-m365.zip | Agent Builder「知識」上傳用(16 個 .txt,備援) |
| GitHub Copilot(VS Code / github.com) | 用 VS Code 開這個 repo,Copilot Chat 的 agent 下拉選 `atlas-kb`;定義在 `.github/agents/atlas-kb.agent.md` |

## 5. 這一頁是怎麼來的

| 項 | 值 |
|---|---|
| 產生時間 | 2026-09-21 13:52 |
| 產生者 | `docs/tools/build_site_index.py`(可重跑;行數與一句話從兩份 README 動態抽) |
| 站台規模 | 畫面 911 · 實體表 437 · 報表範本 608 |
| 已知缺陷 | 1,682 條;兩條死碼線聯集 151 支畫面一按就 NRE |
| 文件份數 | 總覽 1 + 架構 1 + 速查卡 1 + 症狀表 1 + 手冊 9 + 模組篇 29 + 查詢頁 3 |

> 數字與文件同步的方法:改過 `Dev/` 之後跑 `atlas_scan.py --index --refresh`,再依序重生查詢頁,最後重跑本支。

由 build_doc.py v2.0.0 於 2026-09-21 13:52 產生 · 標題 11 · 圖 0 · 表格 9 · 程式錨點 0 · § 連結 1 · 引用檢查：停用

快速鍵：/ 或 Ctrl+K 搜尋目錄 · Esc 清除／關閉放大圖 · 點章節標題左側方塊可收合
